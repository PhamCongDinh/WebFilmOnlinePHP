function ThemPhim() {
    var Ten_Phim = $("#Ten_Phim").val();
    var Anh_Phim = document.getElementById("Anh_Phim").files[0];
    var NgayPhatHanh = $("#NgayPhatHanh").val();
    var ThoiLuong = $("#ThoiLuong").val();
    var MoTa = $("#MoTa").val();
    var HangPhim = $("#HangPhim").val();
    var LoaiPhim = $("#LoaiPhim").val();

    if (!Ten_Phim) {
        alert("Tên phim không được để trống");
        return false;
    }
    if (!Anh_Phim) {
        alert("Ảnh phim không được để trống");
        return false;
    }
    if (!NgayPhatHanh) {
        alert("Ngày phát hành không được để trống");
        return false;
    }
    if (!ThoiLuong) {
        alert("Thời lượng không được để trống");
        return false;
    }
    if (!MoTa) {
        alert("Mô tả không được để trống");
        return false;
    }
    if (!HangPhim) {
        alert("Hãng phim không được để trống");
        return false;
    }
    if (!LoaiPhim) {
        alert("Loại phim không được để trống");
        return false;
    }

    var formData = new FormData();
    formData.append("Ten_Phim", Ten_Phim);
    formData.append("AnhPhim", Anh_Phim);
    formData.append("NgayPhatHanh", NgayPhatHanh);
    formData.append("ThoiLuongPhim", ThoiLuong);
    formData.append("MoTa", MoTa);
    formData.append("TenHP", HangPhim);
    formData.append("Ten_LP", LoaiPhim);
    formData.append("TongSoTap", 100);
    console.log(formData.getAll);
    console.log(Anh_Phim)
    $.ajax({
        type: "POST",
        url: "http://127.0.0.1:8000/api/newphim",
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            window.location.href = 'bophim.html';
            // if (Array.isArray(response) && response.length >= 2 && response[0] === "success") {
            //     var phimData = response[1];
            //     console.log("Thông tin bộ phim mới:", phimData);
            //     alert("Phim đã được thêm mới: " + phimData.Ten_Phim);
            //     window.location.href = '../bophim.html';

            // } else {
            //     console.error("Dữ liệu trả về không hợp lệ:", response);
            //     alert("Có lỗi xảy ra khi nhận dữ liệu từ server.");
            // }

        },
        // error: function (xhr, textStatus, errorThrown) {
        //     console.error("Yêu cầu Ajax thất bại:", textStatus, errorThrown);
        //     alert("Có lỗi xảy ra khi gửi dữ liệu lên server.");
        // }
    });
}



$.ajax({
    type: "GET",
    url: "http://127.0.0.1:8000/api/getlh",

    contentType: "application/json; charset=utf-8",
    dataType: "json",

    success: function (response) {
        console.log(response.LoaiPhim)
        $.each(response.LoaiPhim, function (index, item) {
            $("#LoaiPhim").append('<option value="' + item.ID + '">' + item.Ten_LP + '</option>');

        });
        $.each(response.HangPhim, function (index, item) {
            $("#HangPhim").append('<option value="' + item.ID + '">' + item.Ten_HangPhim + '</option>');

        });


    },
    error: function (jqXHR, textStatus, errorThrown) {
        console.error("Yêu cầu Ajax thất bại:", textStatus, errorThrown);
    }
});