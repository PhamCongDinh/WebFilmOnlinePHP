

$.ajax({
    type: "GET",
    url: "http://127.0.0.1:8000/api/getphim",

    contentType: "application/json; charset=utf-8",
    dataType: "json",

    success: function (response) {
        $("#phim").empty();
        var phimArray = response;

        phimArray.forEach(function (phimItem) {
            $("#phim").append('<option value="' + phimItem.ID + '">' + phimItem.Ten_Phim + '</option>');
        });

    },
    error: function (jqXHR, textStatus, errorThrown) {
        console.error("Yêu cầu Ajax thất bại:", textStatus, errorThrown);
    }
});

load()

function load() {
    $("#phim").change(function () {
        var selectedPhimId = $(this).val();

        $.ajax({
            type: "GET",
            url: "http://127.0.0.1:8000/api/danhsachphim/" + selectedPhimId,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                var phimdata = $("#phimdata");
                var str = ''
                $.each(response, function (index, item) {
                    str += `<tr>
                        <td class="text-secondary text-xs font-weight-bold ">
                          <div class="text-center">${item.Ten_Phim}
                          </div>
                        </td>
                        <td class="text-secondary text-center text-xs font-weight-bold">
                          <img src="./../../../view/images/${item.Anh_Phim}" alt="" width="80px">
                        </td>
                        <td class="text-center mb-0 text-sm">
                        ${item.TapSo}
                        </td>
                        <td class="text-center mb-0 text-sm">
                        ${item.ThoiGianChieu}
                        </td>
                        <td class="text-secondary text-center text-xs font-weight-bold">
                          <iframe
                            src="${item.URL_Phim}"
                            frameborder="0" width="180px" height="80px"></iframe>
                        </td>
                        <td class="align-middle">
                          <a href="editsphim.html?id=${item.ID}" style="background-color: aqua;">Sửa</a> |
                          <a onclick="deletephim(${item.ID})" style="background-color: red;color:white">Xóa</a>
        
                        </td>
                      </tr>`

                });
                phimdata.html(str);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.error("Yêu cầu Ajax thất bại:", textStatus, errorThrown);
            }
        });
    });


}


function deletephim(id) {
    console.log(id)
    if (confirm("Bạn có chắc chắn muốn xóa?")) {
        $.ajax({
            type: "delete",
            url: "http://127.0.0.1:8000/api/deletephim/" + id,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                alert("Phim đã được xóa thành công!");
                load();

            },
            error: function (xhr, status, error) {
                alert("Đã xảy ra lỗi trong quá trình xóa phim!");
            }
        });
    }
}

