var url = window.location.href;
var searchParams = new URLSearchParams(new URL(url).search);
var id = searchParams.get('id');
$.ajax({
    type: "GET",
    url: "http://127.0.0.1:8000/api/detail/" + id,

    contentType: "application/json; charset=utf-8",
    dataType: "json",

    success: function (response) {
        $("#ten_phim").val(response[0].ID_Phim);
        $("#tapso").val(response[0].TapSo);
        $("#thoigianchieu").val(response[0].ThoiGianChieu);
        $("#thoihan").val(response[0].ThoiHan);
        $("#thoiluong").val(response[0].ThoiLuong);
        $("#url_trailer").val(response[0].URL_Trailer);
        $("#url_tapphim").val(response[0].URL_Phim);
        $("#ten_phim").append('<option value="' + response[0].ID_Phim + '">' + response[0].Ten_Phim + '</option>');


    }
})

// $.ajax({
//     type: "GET",
//     url: "http://127.0.0.1:8000/api/getphim",

//     contentType: "application/json; charset=utf-8",
//     dataType: "json",
//     success: function (response) {
//         var phimArray = response;

//         phimArray.forEach(function (phimItem) {
//             $("#ten_phim").append('<option value="' + phimItem.ID + '">' + phimItem.Ten_Phim + '</option>');
//         });

//     },
//     error: function (jqXHR, textStatus, errorThrown) {
//         console.error("Yêu cầu Ajax thất bại:", textStatus, errorThrown);
//     }
// });




function edit() {
    var tenphim = $("#ten_phim").val();
    var tapso = $("#tapso").val();
    var thoigian = $("#thoigianchieu").val();
    var thoihan = $("#thoihan").val();
    var thoiluong = $("#thoiluong").val();
    var trailer = $("#url_trailer").val();
    var link = $("#url_tapphim").val();
    if (!tenphim) {
        alert("Tên phim không được để trống");
        return false;
    }
    if (!tapso) {
        alert("Tập số không được để trống");
        return false;
    }
    if (!thoigian) {
        alert("Thời gian chiếu không được để trống");
        return false;
    }
    if (!thoihan) {
        alert("Thời hạn không được để trống");
        return false;
    }
    if (!thoiluong) {
        alert("Thời lượng không được để trống");
        return false;
    }

    if (!link) {
        alert("URL tập phim không được để trống");
        return false;
    }
    const data = {
        'ID': id,
        'ThoiHan': thoihan,
        'TapSo': tapso,
        'ThoiGianChieu': thoigian,
        'ThoiLuong': thoiluong,
        'URL_Phim': link,
        'URL_Trailer': trailer,
        'ID_Phim': tenphim
    }
    $.ajax({
        type: 'PUT',
        url: 'http://127.0.0.1:8000/api/updatephim',
        contentType: 'application/json',
        data: JSON.stringify(data),
        success: function (response) {

            alert("cập nhật thành công")
        },
        error: function (xhr, status, error) {
            console.error('Lỗi khi gửi yêu cầu: ' + error);
        }
    });
}




