

$.ajax({
    type: "GET",
    url: "http://127.0.0.1:8000/api/getphim",

    contentType: "application/json; charset=utf-8",
    dataType: "json",
    success: function (response) {
        $("#ten_phim").empty();
        var phimArray = response;

        phimArray.forEach(function (phimItem) {
            $("#ten_phim").append('<option value="' + phimItem.Ten_Phim + '">' + phimItem.Ten_Phim + '</option>');
        });

    },
    error: function (jqXHR, textStatus, errorThrown) {
        console.error("Yêu cầu Ajax thất bại:", textStatus, errorThrown);
    }
});
function submitForm() {
    var phimData = [];

    var episodeElements = document.querySelectorAll('.episode');
    episodeElements.forEach(function (episodeElement) {
        var tenPhim = episodeElement.querySelector('#ten_phim').value;
        var tapSo = episodeElement.querySelector('#tapso').value;
        var thoiGianChieu = episodeElement.querySelector('#thoigianchieu').value;
        var thoiHan = episodeElement.querySelector('#thoihan').value;
        var thoiLuong = episodeElement.querySelector('#thoiluong').value;
        var urlTrailer = episodeElement.querySelector('#url_trailer').value;
        var urlTapPhim = episodeElement.querySelector('#url_tapphim').value;
        var giaPhim = episodeElement.querySelector('#giaphim').value;

        var phim = {
            ten_phim: tenPhim,
            tapso: tapSo,
            thoigianchieu: thoiGianChieu,
            thoihan: thoiHan,
            thoiluong: thoiLuong,
            url_trailer: urlTrailer,
            url_tapphim: urlTapPhim,
            giaphim: giaPhim
        };

        phimData.push(phim);
    });

    $.ajax({
        type: "POST",
        url: "http://127.0.0.1:8000/api/newtapphim",
        contentType: "application/json",
        data: JSON.stringify(phimData),
        success: function (response) {
            //alert("Phim đã được thêm mới.");
            //window.location.href = '../manager.html';
            console.log(response);
        },
        error: function (xhr, status, error) {
            console.error(xhr.responseText);
        }
    });
}
