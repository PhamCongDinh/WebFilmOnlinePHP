
var url = window.location.href;
var searchParams = new URLSearchParams(new URL(url).search);
var id = searchParams.get('id');

$.ajax({
    type: "GET",
    url: "http://127.0.0.1:8000/api/phimbyid/" + id,
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    success: function (response) {
        if (response.length > 0) {
            var phim = response[0];
            $("#Ten_Phim").val(phim.Ten_Phim);
            $("#NgayPhatHanh").val(phim.NgayPhatHanh);
            $("#ThoiLuong").val(phim.ThoiLuongPhim);
            $("#MoTa").val(phim.MoTa);
            $("#HangPhim").val(phim.ID_HangPhim);
            $("#LoaiPhim").val(phim.ID_LP);
            $("#Current_Anh_Phim").val(phim.Anh_Phim);
            console.log($("#Current_Anh_Phim").val())
            if (phim.Anh_Phim) {
                $("#imageDisplay").html('<img src="./../../../view/images/' + phim.Anh_Phim + '" alt="Selected Image" style="max-width: 300px; max-height: 300px;">');
            }

        }
    },
    error: function (error) {
        console.error("Error fetching phim data:", error);
    }
});


function editbophim() {
    var Ten_Phim = $("#Ten_Phim").val();
    var Anh_Phim = document.getElementById("Anh_Phim").files[0];
    var NgayPhatHanh = $("#NgayPhatHanh").val();
    var ThoiLuong = $("#ThoiLuong").val();
    var MoTa = $("#MoTa").val();
    var HangPhim = $("#HangPhim").val();
    var LoaiPhim = $("#LoaiPhim").val();

    var Current_Anh_Phim = $("#Current_Anh_Phim").val();

    if (!Ten_Phim) {
        alert("Tên phim không được để trống");
        return false;
    }

    if (!NgayPhatHanh) {
        alert("Ngày phát hành không được để trống");
        return false;
    }
    if (!ThoiLuong) {
        alert("Thời lượng không được để trống");
        return false;
    }
    if (!MoTa) {
        alert("Mô tả không được để trống");
        return false;
    }
    if (!HangPhim) {
        alert("Hãng phim không được để trống");
        return false;
    }
    if (!LoaiPhim) {
        alert("Loại phim không được để trống");
        return false;
    }

    var formData = new FormData();
    formData.append("Ten_Phim", Ten_Phim);
    if (Anh_Phim) {
        formData.append("AnhPhim", Anh_Phim);
    } else {
        formData.append("AnhPhim", Current_Anh_Phim);
    }
    //formData.append("AnhPhim", Anh_Phim);
    formData.append("ID", this.id)
    formData.append("NgayPhatHanh", NgayPhatHanh);
    formData.append("ThoiLuongPhim", ThoiLuong);
    formData.append("MoTa", MoTa);
    formData.append("ID_HangPhim", HangPhim);
    formData.append("ID_LP", LoaiPhim);
    formData.append("TongSoTap", 100);
    console.log("click r", formData.get("ID"))
    $.ajax({
        type: "POST",
        url: "http://127.0.0.1:8000/api/editbophim",

        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            window.location.href = 'bophim.html';

            console.log(response)
        }

    });
}

