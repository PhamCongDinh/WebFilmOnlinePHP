$.ajax({
    type: "GET",
    url: "http://127.0.0.1:8000/api/getphim",

    contentType: "application/json; charset=utf-8",
    dataType: "json",

    success: function (response) {
        var phimdata = $("#phim");
        var str = '';
        $.each(response, function (index, item) {

            str += `<tr>
                        <td class="text-secondary text-xs font-weight-bold ">
                          <div class="text-center">${item.Ten_Phim}
                          </div>
                        </td>
                        <td class="text-secondary text-center text-xs font-weight-bold">
                          <img src="./../../../view/images/${item.Anh_Phim}" alt="" width="80px">
                        </td>
                        <td class="text-center mb-0 text-sm">
                        ${item.NgayPhatHanh}
                        </td>
                        <td class="text-center mb-0 text-sm">
                        ${item.Ten_HangPhim}
                        </td>
                        <td class="text-secondary text-center text-xs font-weight-bold">
                        ${item.Ten_LP}
                        </td>
                        <td class="align-middle">
                            <a href="editbophim.html?id=${item.ID}"
                                style="background-color: aqua;">Sửa</a>

                        </td>
                      </tr>`


        });
        phimdata.html(str);


    },
    error: function (jqXHR, textStatus, errorThrown) {
        console.error("Yêu cầu Ajax thất bại:", textStatus, errorThrown);
    }
});