



$("#change").click(function (e) {
    e.preventDefault();
    const passwordold = document.getElementById('passwordold').value;
    const passwordnew = document.getElementById('passwordnew').value;
    const confirmpassword = document.getElementById('confirmpassword').value;
    if (passwordold === passwordnew) {
        alert('mật khẩu đã dùng hãy sử dụng mật khẩu mới hơn');
        return;
    }
    if (passwordnew !== confirmpassword) {
        alert('Mật khẩu mới và nhập lại mật khẩu mới không khớp.');
        return;
    }
    var data = {
        "ID": localStorage.getItem("userID"),
        "matkhau": passwordold,
        "matkhaumoi": passwordnew
    };
    $.ajax({
        type: "POST",
        url: 'http://127.0.0.1:8000/api/changepassword',
        contentType: 'application/json',
        data: JSON.stringify(data),

        success: function (response) {

            alert("Đổi mật khẩu thành công\n Đăng nhập lại!")
            this.logout();


        },
        error: function (xhr, status, error) {

            alert("Mật khẩu cũ không đúng");
        }
    });
});


function logout() {
    localStorage.clear();
    window.location.href = '/authen/login.html';
}