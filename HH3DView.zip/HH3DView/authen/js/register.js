const queryString = window.location.search;
// http://127.0.0.1:5500/authen/thanks.html?partnerCode=MOMOBKUN20180529&orderId=1712889698&requestId=1712889698&amount=10000&orderInfo=Thanh+to%C3%A1n+t%C3%A0i+kho%E1%BA%A3n&orderType=momo_wallet&transId=4020480112&resultCode=0&message=Successful.&payType=napas&responseTime=1712889785268&extraData=%22uername%3DPh%5Cu1ea1m+Vi%5Cu1ec7t+Trung%26password%3D123456%26email%3Dtrung%40gmail.com%22&signature=4809974d1d034bdddbd1e5f5bf24985c39b1ff5c91940bdeb6bd24678e7a49dd&paymentOption=momo
const urlParams = new URLSearchParams(queryString);

const partnerCode = urlParams.get('partnerCode');
const orderId = urlParams.get('orderId');
const requestId = urlParams.get('requestId');
const amount = urlParams.get('amount');
const orderInfo = urlParams.get('orderInfo');
const orderType = urlParams.get('orderType');
const transId = urlParams.get('transId');
const resultCode = urlParams.get('resultCode');
const message = urlParams.get('message');
const payType = urlParams.get('payType');
const responseTime = urlParams.get('responseTime');
const extraData = urlParams.get('extraData');
const signature = urlParams.get('signature');
const paymentOption = urlParams.get('paymentOption');
const urlextra = new URLSearchParams()

const extraDataEncoded = extraData;

const cleanedExtraData = extraDataEncoded.replace(/^"|"$|^'|'$/g, '');

const pairs = cleanedExtraData.split('&');

const extraDataObject = {};

pairs.forEach(pair => {
    const [key, value] = pair.split('=');

    const decodedValue = value.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) =>
        String.fromCharCode(parseInt(hex, 16))
    );

    extraDataObject[key] = decodedValue;
});

const username = extraDataObject['username'];
const password = extraDataObject['password'];
const email = extraDataObject['email'];

// console.log(`Username: ${username}`);
// console.log(`Password: ${password}`);
// console.log(`Email: ${email}`);

$(document).ready(function () {
    // e.preventDefault(); // Ngăn chặn việc gửi mẫu theo cách mặc định

    var data = {
        "IDhd": orderId,
        "TenTK": username,
        "matkhau": password,
        "gia": amount,
        "email": email,
        "loai": 1
    };
    console.log(data);
    $.ajax({
        type: "POST",
        url: 'http://127.0.0.1:8000/api/registers',
        contentType: 'application/json',
        data: JSON.stringify(data),

        success: function (response) {
        },
        error: function (xhr, status, error) {

            console.error('Lỗi AJAX:', status, error);
        }
    });
});
$("#register").click(function (e) {
    e.preventDefault(); // Ngăn chặn việc gửi mẫu theo cách mặc định
    alert("cảm ơn bạn đã đăng ký");
    window.location.href = '/authen/login.html';

});

// $("#register").click(function (e) {
//     e.preventDefault(); // Ngăn chặn việc gửi mẫu theo cách mặc định

//     var data = {
//         "IDhd": orderId,
//         "TenTK": username,
//         "matkhau": password,
//         "gia": amount,
//         "email": email,
//         "loai": 1
//     };
//     console.log(data);
//     $.ajax({
//         type: "POST",
//         url: 'http://127.0.0.1:8000/api/registers',
//         contentType: 'application/json',
//         data: JSON.stringify(data),

//         success: function (response) {
//             if (response) {
//                 alert("cảm ơn bạn đã đăng ký");
//                 window.location.href = '../login.html';
//             } else {
//                 alert("Đăng nhập thất bại. " + response.message);
//             }
//         },
//         error: function (xhr, status, error) {

//             console.error('Lỗi AJAX:', status, error);
//         }
//     });
// });