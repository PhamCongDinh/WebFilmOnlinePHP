$("#send").click(function (e) {
    e.preventDefault();
    var email = $("#email").val();

    var data = {
        "email": email,
    };

    $.ajax({
        type: "POST",
        url: 'http://127.0.0.1:8000/api/forgot-password',
        contentType: 'application/json',
        data: JSON.stringify(data),

        success: function (response) {
            if (response.status === 404) {
                alert("Tài khoản không tồn tại");
            }
            else {
                alert("bạn hãy kiểm tra email");
                window.location.href = 'login.html';
            }

        },
        error: function (xhr, status, error) {

            console.error('Lỗi AJAX:', status, error);
        }
    });
});
