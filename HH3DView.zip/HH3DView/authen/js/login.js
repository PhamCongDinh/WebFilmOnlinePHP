$("#login").click(function (e) {
    e.preventDefault();
    var email = $("#email").val();
    var password = $("#passwordField").val();

    var data = {
        "email": email,
        "matkhau": password
    };

    $.ajax({
        type: "POST",
        url: 'http://127.0.0.1:8000/api/login',
        contentType: 'application/json',
        data: JSON.stringify(data),

        success: function (response) {
            localStorage.setItem("token", response.token);
            localStorage.setItem("userID", response.userID);
            window.location.href = '../view/index.html';

        },
        error: function (xhr, status, error) {
            alert("email hoặc mặt khẩu không đúng")
            console.error('Lỗi AJAX:', status, error);
        }
    });
});
