var countDownTime = 0;//1 * 60 * 1000;
var startTime = new Date().getTime();
var ajaxExecuted = false;

function countdownTimer() {
    var currentTime = new Date().getTime();
    if (currentTime - startTime >= countDownTime && !ajaxExecuted) {
        executeAjax();
        ajaxExecuted = true;
    } else {
        setTimeout(countdownTimer, 1000);
    }
}

function executeAjax() {
    $.ajax({
        url: 'http://127.0.0.1:8000/api/addlsxp',
        type: 'POST',
        data: {
            'ID_TapPhim': sessionStorage.getItem("idtapphim"),
            'ID_TK': localStorage.getItem("userID")
        },
        success: function (response) {
            // alert("đã thêm vào lich sử thành công!");
            // console.log('đã thêm vào lich sử thành công!');
        },
        error: function (xhr, status, error) {
            console.error('thất bại:', error);
        }
    });
}

$(document).ready(function () {
    countdownTimer();
});
