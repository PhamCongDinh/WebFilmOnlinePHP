$.ajax({
    url: 'http://127.0.0.1:8000/phimhaynhat',
    type: 'GET',
    dataType: 'json',
    success: function (response) {
        // console.log(response);
        var phimhays = $("#phimhay");
        var str = '';
        console.log(response)
        $.each(response, function (index, item) {
            str += `
                    <div class="item">
                        <a href="phim.html?phim=${item.Ten_Phim}" title="${item.Ten_Phim}"
                            title="Đấu Phá Thương Khung OVA - Ước Hẹn 3 Năm">
                            <div class="item-link">
                                <img src="images/${item.Anh_Phim}"
                                    class="post-thumb" alt="Đấu Phá Thương Khung OVA - Ước Hẹn 3 Năm"
                                    title="Đấu Phá Thương Khung OVA - Ước Hẹn 3 Năm" />
                            </div>
                            <h3 class="title">${item.Ten_Phim}</h3>
                        </a>
                        <div>${item.SoLanXem} lượt xem</div>
                    </div>`;
        });
        phimhays.html(str);
    },
    error: function (xhr, textStatus, errorThrown) {
        console.error('Lỗi khi lấy dữ liệu phim:', errorThrown);
    }
});