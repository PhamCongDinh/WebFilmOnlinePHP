$(document).ready(function () {
    var currentDate = new Date();
    console.log(currentDate)
    var currentDay = currentDate.getDay() + 1; // Lấy ngày hiện tại (0-6)
    console.log(currentDay)
    loadDanhSachPhim(currentDay)


    $('ul.nav-justified li a').on('click', function () {
        var thu = $(this).attr('aria-controls').split('-')[1];
        // console.log(thu)
        loadDanhSachPhim(thu);
    });

    function loadDanhSachPhim(thu) {

        $.ajax({
            url: 'http://127.0.0.1:8000/danh-sach-phim/' + thu,
            type: 'GET',
            success: function (result) {
                var phimbydate = $("#phimbydate");
                phimbydate.empty();
                var str = '';

                $.each(result, function (index, item) {
                    str += `
                    <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item">
                        <div class="halim-item">
                            <a class="halim-thumb" href="phim.html?phim=${item.Ten_Phim}" title="${item.Ten_Phim}">
                                <figure><img class="img-responsive" src="images/${item.Anh_Phim}" title="${item.Ten_Phim}"></figure>
                                <span class="episode">Tập ${item.SoLuongTap}/${item.TongSoTap} </span>
                                <div class="icon_overlay"></div>

                                <div class="halim-post-title-box">
                                    <div class="halim-post-title">
                                        <h2 class="entry-title">${item.Ten_Phim}</h2>
                                        <p class="original_title">${item.MoTa}</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>`;
                });
                phimbydate.html(str);
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(textStatus + ': ' + errorThrown);
            }
        });
    }

});
