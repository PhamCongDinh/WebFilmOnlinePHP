$(document).ready(function () {
    $('#search').on('keydown', function (e) {
        if (e.keyCode == 13) {
            e.preventDefault();
            searchPhim();
        }
    });

    $('#search-form-pc').on('submit', function (e) {
        e.preventDefault();
        searchPhim();
    });
    function searchPhim() {
        var key = $('#search').val();
        $.ajax({
            url: "http://127.0.0.1:8000/search-phim/" + key,
            type: "GET",
            dataType: "json",
            success: function (result) {
                // console.log(result);
                var sanphams = $("#sanphams");
                sanphams.empty();
                var str = '';

                $.each(result, function (index, item) {
                    str += `
                    <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item">
                        <div class="halim-item">
                            <a class="halim-thumb" href="phim.html?phim=${item.Ten_Phim}" title="${item.Ten_Phim}">
                                <figure><img class="img-responsive" src="images/${item.Anh_Phim}" title="${item.Ten_Phim}"></figure>
                                <span class="episode">Tập ${item.SoLuongTap}/${item.TongSoTap} </span>
                                <div class="icon_overlay"></div>

                                <div class="halim-post-title-box">
                                    <div class="halim-post-title">
                                        <h2 class="entry-title">${item.Ten_Phim}</h2>
                                        <p class="original_title">${item.MoTa}</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>`;
                });
                sanphams.html(str);
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(textStatus + ": " + errorThrown);
            }
        });
    }
});
