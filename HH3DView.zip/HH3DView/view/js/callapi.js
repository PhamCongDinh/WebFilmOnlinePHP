//tất cả phim
function getallfilms() {
    $.ajax({
        url: "http://127.0.0.1:8000/phim",
        type: "GET",
        dataType: "json",
        success: function (result) {
            // console.log(result);
            var sanphams = $("#sanphams");
            var str = '';

            $.each(result, function (index, item) {
                str += `
                    <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item">
                        <div class="halim-item">
                            <a class="halim-thumb" href="phim.html?phim=${item.Ten_Phim}" title="${item.Ten_Phim}">
                                <figure><img class="img-responsive" src="images/${item.Anh_Phim}" title="${item.Ten_Phim}"></figure>
                                <span class="episode">Tập ${item.SoLuongTap}/${item.TongSoTap} </span>
                                <div class="icon_overlay"></div>

                                <div class="halim-post-title-box">
                                    <div class="halim-post-title">
                                        <h2 class="entry-title">${item.Ten_Phim}</h2>
<h2>${item.DanhGia !== null ? item.DanhGia : "?"}/5 ★</h2>

                                        <p class="original_title">${item.MoTa}</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>`;
            });

            sanphams.html(str);
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log(textStatus + ": " + errorThrown);
        }
    });
}

$.ajax({
    url: "http://127.0.0.1:8000/phimmoinhat",
    type: "GET",
    dataType: "json",
    success: function (result) {
        // console.log(result);
        var sanphams = $("#phimmoinhat");
        var str = '';

        $.each(result, function (index, item) {
            str += `
                <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item">
                    <div class="halim-item">
                        <a class="halim-thumb" href="phim.html?phim=${item.Ten_Phim}" title="${item.Ten_Phim}">
                            <figure><img class="img-responsive" src="images/${item.Anh_Phim}" title="${item.Ten_Phim}"></figure>
                            <span class="episode">Tập ${item.SoLuongTap}/${item.TongSoTap} </span>
                            <div class="icon_overlay"></div>

                            <div class="halim-post-title-box">
                                <div class="halim-post-title">
                                    <h2 class="entry-title">${item.Ten_Phim}</h2>
<h2>${item.DanhGia !== null ? item.DanhGia : "?"}/5 ★</h2>

                                    <p class="original_title">${item.MoTa}</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </article>`;
        });

        sanphams.html(str);
    },
    error: function (xhr, textStatus, errorThrown) {
        console.log(textStatus + ": " + errorThrown);
    }
});


//phân trang danh sách phim

$(document).ready(function () {
    var currentPage = 1;

    function loadPaginatedData(page) {
        $.ajax({
            url: 'http://127.0.0.1:8000/api/page?page=' + page,
            type: 'GET',
            dataType: 'json',
            success: function (response) {
                // console.log(response);
                var sanphams = $("#sanphams");
                var str = '';

                $.each(response.phimData, function (index, item) {
                    str += `
                    <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item">
                        <div class="halim-item">
                            <a class="halim-thumb" href="phim.html?phim=${item.Ten_Phim}" title="${item.Ten_Phim}">
                                <figure><img class="img-responsive" src="images/${item.Anh_Phim}" title="${item.Ten_Phim}"></figure>
                                <span class="episode">Tập ${item.SoLuongTap}/${item.TongSoTap} </span>
                                <div class="icon_overlay"></div>
                                <div class="halim-post-title-box">
                                    <div class="halim-post-title">
                                        <h2 class="entry-title">${item.Ten_Phim}</h2>
<h2>${item.DanhGia !== null ? item.DanhGia : "?"}/5 ★</h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>`;
                });
                sanphams.html(str);
                createPagination(response.totalPages);
            },
            error: function (xhr, textStatus, errorThrown) {
                console.error('Lỗi khi lấy dữ liệu phim:', errorThrown);
            }
        });
    }

    function createPagination(totalPages) {
        var paginationHtml = '<ul class="pagination">';
        for (var i = 1; i <= totalPages; i++) {
            paginationHtml += '<li class="page-item"><a class="page-link" href="#" data-page="' + i + '">' + i + '</a></li>';
        }
        paginationHtml += '</ul>';
        $('#pagination').html(paginationHtml);

        $('#pagination').on('click', 'a.page-link', function (e) {
            e.preventDefault();
            var page = $(this).data('page');
            loadPaginatedData(page);
        });
    }
    loadPaginatedData(currentPage);
});


//xem nhiều nhất

$.ajax({
    url: 'http://127.0.0.1:8000/phimhaynhat',
    type: 'GET',
    dataType: 'json',
    success: function (response) {
        // console.log(response);
        var phimhays = $("#phimhay");
        var str = '';
        console.log(response)
        $.each(response, function (index, item) {
            str += `
                    <div class="item">
                        <a href="phim.html?phim=${item.Ten_Phim}" title="${item.Ten_Phim}"
                            title="Đấu Phá Thương Khung OVA - Ước Hẹn 3 Năm">
                            <div class="item-link">
                                <img src="images/${item.Anh_Phim}"
                                    class="post-thumb" alt="Đấu Phá Thương Khung OVA - Ước Hẹn 3 Năm"
                                    title="Đấu Phá Thương Khung OVA - Ước Hẹn 3 Năm" />
                            </div>
                            <h3 class="title">${item.Ten_Phim}</h3>
                        </a>
                        <div>${item.SoLanXem} lượt xem</div>
                    </div>`;
        });
        phimhays.html(str);
    },
    error: function (xhr, textStatus, errorThrown) {
        console.error('Lỗi khi lấy dữ liệu phim:', errorThrown);
    }
});
