
$(document).ready(function () {
    var id = getParameterByName("phim");

    $.ajax({
        url: "http://127.0.0.1:8000/phimbyid/" + id,
        type: "GET",
        dataType: "json",
        success: function (result) {
            // console.log(result);
            var phimbyid = $("#phimbyid");
            var str = '';
            var nd = '';
            var noidung = $("#noidung");
            $.each(result, function (index, item) {
                str += `
                <div class="movie_info col-xs-12">
                <div class="movie-poster col-md-4">
                    <img class="movie-thumb"
                        src="images/${item.Anh_Phim}"
                        alt="">

                </div>
                <div class="film-poster col-md-8">
                    <div class="movie-detail">
                        <h1 class="entry-title">${item.Ten_Phim}</h1>
                        <p class="released">
                            <i class="hl-clock"></i>
                            ${item.ThoiLuongPhim}
                        </p>
                        
                        <p class="category">
                            Thể Loại: ${item.Ten_LP}
                        </p>
                    </div>
                </div>
            </div>`;
                nd += `<p> ${item.MoTa}</p>`
            });

            phimbyid.html(str);
            noidung.html(nd);
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log(textStatus + ": " + errorThrown);
        }
    });
});


$(document).ready(function () {
    var id = getParameterByName("phim");

    $.ajax({
        url: "http://127.0.0.1:8000/tapphimbyid/" + id,
        type: "GET",
        dataType: "json",
        success: function (result) {
            console.log(result);
            var tapphimbyid = $("#tapphimbyid");
            var str = '';
            console.log(id)
            $.each(result, function (index, item) {
                str += `
                <li class="halim-episode halim-episode-1-tap-53">
                                                    <a href="playphim.html?phim=${item.Ten_Phim}&&tapso=${item.TapSo}"
                                                        title="53">
                                                        <span class="halim-info-1-tap-53 box-shadow halim-btn"
                                                            data-post-id="2452" data-server="1"
                                                            data-episode-slug="tap-53" data-position=""
                                                            data-embed="1">${item.TapSo}</span>
                                                    </a>
                                                </li>`;
            });

            tapphimbyid.html(str);
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log(textStatus + ": " + errorThrown);
        }
    });
});


function getParameterByName(name) {
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(window.location.search);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
