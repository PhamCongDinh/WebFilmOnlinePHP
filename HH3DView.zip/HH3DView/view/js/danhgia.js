$(document).ready(function () {
    $('input[type=radio][name=rating]').change(function () {
        var ratingValue = $(this).val();

        $.ajax({
            url: 'http://127.0.0.1:8000/api/danhgia',
            type: 'POST',
            data: {
                SoDiem: ratingValue,
                'ID_TapPhim': sessionStorage.getItem("idtapphim"),
                'ID_TK': localStorage.getItem("userID")
            },
            success: function (response) {
                // alert("thanh cong")
                // console.log('Đánh giá thành công!'); 
            },
            error: function (xhr, status, error) {
                console.error('Đánh giá thất bại:', error);
            }
        });
    });
});
