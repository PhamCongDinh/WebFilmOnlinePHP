$(document).ready(function () {

    function fetchRating() {
        var ID_TapPhim = sessionStorage.getItem("idtapphim");
        var ID_TK = localStorage.getItem("userID")
        console.log(ID_TapPhim, ID_TK)
        $.ajax({
            url: 'http://127.0.0.1:8000/api/sodiem?ID_TapPhim=' + ID_TapPhim + '&ID_TK=' + ID_TK,
            method: 'GET',
            // data: {
            //     'ID_TapPhim': sessionStorage.getItem("idtapphim"),
            //     'ID_TK': localStorage.getItem("userID")
            // },
            success: function (response) {
                console.log(response);
                setRating(response.data[0].SoDiem);
            },
            error: function (error) {
                console.error('Error fetching rating:', error);
            }
        });
    }

    function setRating(rating) {
        $(`input[name="rating"][value="${rating}"]`).prop('checked', true);
    }

    fetchRating();




    $('input[type=radio][name=rating]').change(function () {
        var ratingValue = $(this).val();

        $.ajax({
            url: 'http://127.0.0.1:8000/api/danhgia',
            type: 'POST',
            data: {
                SoDiem: ratingValue,
                'ID_TapPhim': sessionStorage.getItem("idtapphim"),
                'ID_TK': localStorage.getItem("userID")
            },
            success: function (response) {
                // alert("thanh cong")
                // console.log('Đánh giá thành công!'); 
            },
            error: function (xhr, status, error) {
                console.error('Đánh giá thất bại:', error);
            }
        });
    });
});
