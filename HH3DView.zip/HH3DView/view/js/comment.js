//lấy tất cả comment
$(document).ready(function () {
    var tapso = getParameterByName('tapso');
    var ten = getParameterByName("phim");

    function getAllComments() {
        $.ajax({
            url: "http://127.0.0.1:8000/api/getallcmmt?TapSo=" + tapso + "&Ten_Phim=" + ten,
            type: "GET",
            contentType: 'application/json',
            success: function (response) {
                // console.log(response);
                displayComments(response.success);
            },
            error: function (xhr, status, error) {
                console.error("Lỗi khi gửi yêu cầu: " + error);
            }
        });
    }

    getAllComments();

    function displayComments(comments) {
        var commentList = $("#commentList");
        commentList.empty();
        $.each(comments, function (index, comment) {
            var li = $("<li></li>");
            li.css('display', 'flex');
            li.html("<p>" + comment.Ten_TK + ": </p><span>" + comment.NoiDung + "</span>");
            commentList.append(li);
        });
    }
    //thêm comment
    $('#commentForm').submit(function (event) {
        event.preventDefault();
        let commentText = $('#commentText').val().trim();

        if (commentText !== '') {
            let formData = {
                'NoiDung': commentText,
                'ID_TapPhim': sessionStorage.getItem("idtapphim"),
                'ID_TK': localStorage.getItem("userID")
            };

            $.ajax({
                type: 'POST',
                url: 'http://127.0.0.1:8000/api/comment',
                contentType: 'application/json',
                data: JSON.stringify(formData),
                success: function (response) {
                    getAllComments();
                    $('#commentText').val('');
                },
                error: function (xhr, status, error) {
                    console.error('Lỗi khi gửi yêu cầu: ' + error);
                }
            });
        }
        else {
            alert("Chưa có nội dung")
        }
    });
});

