
$(document).ready(function () {
    var id = getParameterByName('tapso');
    var ten = getParameterByName("phim");
    if (!localStorage.getItem("token")) {
        alert("bạn phải đăng nhập mới xem được!");
        window.location.href = '../authen/login.html';
    } else {


        $.ajax({
            url: "http://127.0.0.1:8000/playphim/" + id + '/' + ten,
            type: "GET",
            dataType: "json",
            beforeSend: function (xhr) {
                xhr.setRequestHeader("Authorization", localStorage.getItem("token"));
            },
            success: function (result) {
                // console.log(result);
                var playphimbyid = $("#playphimbyid");
                var str = '';

                $.each(result, function (index, item) {
                    sessionStorage.setItem("idtapphim", item.ID)
                    str += `
                
                    <div id="ajax-player" class="player">
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item"
                            src="${item.URL_Phim}"
                            
                            allowfullscreen></iframe>

                            
                    </div>
                </div>
               
            

                

                        `;
                });

                // Gán chuỗi HTML đã tạo vào phần tử có id là "sanphams"
                playphimbyid.html(str);
            },
            error: function (xhr, textStatus, errorThrown) {
                // Xử lý lỗi
                console.log(textStatus + ": " + errorThrown);
            }
        });
    }
});
function getParameterByName(name) {
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(window.location.href);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}