$(document).ready(function () {
    $.ajax({
        url: "http://127.0.0.1:8000/api/getalllsx?ID=" + localStorage.getItem("userID"),
        type: "GET",
        dataType: "json",
        success: function (result) {
            // console.log(result);
            var danhsach = $("#danhsach");
            var str = '';

            $.each(result, function (index, item) {
                str += `<div style="display: flex;    margin: 5px;
                ">

                <img src="images/${item.Anh_Phim}" alt="Image" width="70px">
                <div>
                    <a href="phim.html?phim=${item.Ten_Phim}">${item.Ten_Phim}</a><br>
                    <a href="playphim.html?phim=${item.Ten_Phim}&&tapso=${item.TapSo}">tập ${item.TapSo}</a>
                    <h6>Thời gian: ${item.create_at}</h6>
                </div>
            </div>`;
            });

            danhsach.html(str);
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log(textStatus + ": " + errorThrown);
        }
    });
});



