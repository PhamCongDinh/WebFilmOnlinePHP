$(document).ready(function () {

    $("#theloai").on("click", "a", function () {
        var tenLP = $(this).data("tenlp");
        loadPhim(tenLP);
    });



    $.ajax({
        url: "http://127.0.0.1:8000/theloai",
        type: "GET",
        dataType: "json",
        success: function (result) {
            // console.log(result);
            var theloai = $("#theloai");
            var str = '';

            $.each(result, function (index, item) {
                str += `
                <li>
                    <a data-tenlp="${item.Ten_LP}" >${item.Ten_LP}</a>
                </li>
                
                `;
            });

            theloai.html(str);
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log(textStatus + ": " + errorThrown);
        }
    });


});






function loadPhim(theLoai) {
    $.ajax({
        url: 'http://127.0.0.1:8000/phimbytheloai/' + theLoai,
        type: 'GET',
        success: function (result) {
            var sanphams = $("#sanphams");
            sanphams.empty();
            var str = '';

            $.each(result, function (index, item) {
                str += `
                    <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item">
                        <div class="halim-item">
                            <a class="halim-thumb" href="phim.html?phim=${item.Ten_Phim}" title="${item.Ten_Phim}">
                                <figure><img class="img-responsive" src="images/${item.Anh_Phim}" title="${item.Ten_Phim}"></figure>
                                <span class="episode">Tập ${item.SoLuongTap}/${item.TongSoTap} </span>
                                <div class="icon_overlay"></div>

                                <div class="halim-post-title-box">
                                    <div class="halim-post-title">
                                        <h2 class="entry-title">${item.Ten_Phim}</h2>
                                        <p class="original_title">${item.MoTa}</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>`;
            });

            sanphams.html(str);
        },
        error: function (xhr, textStatus, errorThrown) {
            console.error('Lỗi khi tải danh sách phim:', textStatus, errorThrown);
        }
    });
}