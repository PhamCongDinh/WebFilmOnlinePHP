// Lấy chuỗi truy vấn từ URL hiện tại
const queryString = `http://127.0.0.1:5500/authen/thanks.html?partnerCode=MOMOBKUN20180529&orderId=1712889698&requestId=1712889698&amount=10000&orderInfo=Thanh+to%C3%A1n+t%C3%A0i+kho%E1%BA%A3n&orderType=momo_wallet&transId=4020480112&resultCode=0&message=Successful.&payType=napas&responseTime=1712889785268&extraData=%22uername%3DPh%5Cu1ea1m+Vi%5Cu1ec7t+Trung%26password%3D123456%26email%3Dtrung%40gmail.com%22&signature=4809974d1d034bdddbd1e5f5bf24985c39b1ff5c91940bdeb6bd24678e7a49dd&paymentOption=momo`;

// Phân tích cú pháp chuỗi truy vấn
const urlParams = new URLSearchParams(queryString);

// Lấy các giá trị cụ thể từ URL
const partnerCode = urlParams.get('partnerCode');
const orderId = urlParams.get('orderId');
const requestId = urlParams.get('requestId');
const amount = urlParams.get('amount');
const orderInfo = urlParams.get('orderInfo');
const orderType = urlParams.get('orderType');
const transId = urlParams.get('transId');
const resultCode = urlParams.get('resultCode');
const message = urlParams.get('message');
const payType = urlParams.get('payType');
const responseTime = urlParams.get('responseTime');
const extraData = urlParams.get('extraData');
const signature = urlParams.get('signature');
const paymentOption = urlParams.get('paymentOption');
const urlextra = new URLSearchParams()
// In giá trị của từng tham số
console.log(`Partner Code: ${partnerCode}`);
console.log(`Order ID: ${orderId}`);
console.log(`Request ID: ${requestId}`);
console.log(`Amount: ${amount}`);
console.log(`Order Info: ${orderInfo}`);
console.log(`Order Type: ${orderType}`);
console.log(`Transaction ID: ${transId}`);
console.log(`Result Code: ${resultCode}`);
console.log(`Message: ${message}`);
console.log(`Pay Type: ${payType}`);
console.log(`Response Time: ${responseTime}`);
console.log(`Extra Data: ${extraData}`);
console.log(`Signature: ${signature}`);
console.log(`Payment Option: ${paymentOption}`);
const extraDataEncoded = extraData;

// Loại bỏ dấu ngoặc kép ở đầu và cuối của chuỗi extraData (nếu có)
const cleanedExtraData = extraDataEncoded.replace(/^"|"$|^'|'$/g, '');

// Tách chuỗi extraData thành các cặp khóa-giá trị
const pairs = cleanedExtraData.split('&');

// Tạo một đối tượng để lưu trữ các cặp khóa-giá trị
const extraDataObject = {};

// Lặp qua các cặp khóa-giá trị và thêm chúng vào đối tượng extraDataObject
pairs.forEach(pair => {
    // Tách cặp khóa-giá trị
    const [key, value] = pair.split('=');

    // Giải mã chuỗi giá trị (nếu cần)
    const decodedValue = value.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) =>
        String.fromCharCode(parseInt(hex, 16))
    );

    // Lưu cặp khóa-giá trị vào đối tượng extraDataObject
    extraDataObject[key] = decodedValue;
});

// Lấy các giá trị từ extraDataObject
const username = extraDataObject['uername'];
const password = extraDataObject['password'];
const email = extraDataObject['email'];

// In các giá trị ra console
console.log(`Username: ${username}`); // In ra: Phạm Việt Trung
console.log(`Password: ${password}`); // In ra: 123456
console.log(`Email: ${email}`); // In ra: trung@gmail.com