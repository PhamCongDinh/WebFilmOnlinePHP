<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePhimTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('phim', function (Blueprint $table) {
            $table->id();
            $table->string('Ten_Phim');
            $table->string('Anh_Phim');
            $table->dateTime('NgayPhatHanh');
            $table->string('ThoiLuongPhim')->nullable();
            $table->string('MoTa')->nullable();
            $table->float('DanhGia')->nullable();
            $table->unsignedBigInteger('ID_HangPhim')->nullable();
            $table->unsignedBigInteger('ID_LP')->nullable();
            $table->timestamps();

            $table->foreign('ID_HangPhim')->references('ID')->on('hangphim')->onDelete('set null')->onUpdate('cascade');
            $table->foreign('ID_LP')->references('ID')->on('loaiphim')->onDelete('set null')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('phim');
    }
}
