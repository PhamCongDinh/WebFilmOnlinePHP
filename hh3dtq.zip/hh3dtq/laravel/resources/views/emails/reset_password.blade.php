<!DOCTYPE html>
<html>

<head>
    <title>New Password</title>
</head>

<body>
    <h1>Hello, {{ $user->name }}</h1>
    <p>Your new password is: {{ $newPassword }}</p>
    <p>Please use this password to login and change your password immediately.</p>
</body>

</html>