<!DOCTYPE html>
<html>

<head>
    <title>New Password</title>
</head>

<body>
    <h1>Hello, <?php echo e($user->name); ?></h1>
    <p>Your new password is: <?php echo e($newPassword); ?></p>
    <p>Please use this password to login and change your password immediately.</p>
</body>

</html><?php /**PATH C:\xampp\htdocs\hh3dtq\laravel\resources\views/emails/reset_password.blade.php ENDPATH**/ ?>