<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class AuthenticateMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $token = $request->header('Authorization');

        if (!$token) {
            return response()->json(['error' => 'Token not provided'], 401);
        } else {
            $key = new Key('ThisIsAVeryLongAndSecureSecretKeyForJWTTokenGeneration', 'HS256');
            $decoded = JWT::decode($token, $key);
            return $next($request);
        }
    }
}
