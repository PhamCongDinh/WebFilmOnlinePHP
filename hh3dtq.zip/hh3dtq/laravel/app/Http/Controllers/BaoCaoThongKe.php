<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Http\Request;

class BaoCaoThongKe extends Controller
{
    public function ThongkeTK(Request $req)
    {
        $month = $req->month;
        $year = $req->year;
        if (!$month || !$year) {
            $year =  now()->year;
            $month = now()->month;
        }
        $hoadonThangNam = DB::table('hoadon')
            ->select(DB::raw('count(*) as total'))
            ->whereYear('create_at', $year)
            ->whereMonth('create_at', $month)
            ->first();
        return response()->json([$hoadonThangNam->total]);
    }
    public function ThongKeTapPhim(Request $req)
    {
        $month = $req->month;
        $year = $req->year;

        // Thiết lập điều kiện mặc định cho tháng và năm
        if (!$month || !$year) {
            $year = now()->year;
            $month = now()->month;
        }

        // Thực hiện truy vấn sử dụng Laravel Query Builder
        $totalEpisodes = DB::table('tapphim')
            ->join('chitiethdn', 'tapphim.ID', '=', 'chitiethdn.ID_TapPhim')
            ->join('hoadonnhap', 'chitiethdn.ID_PNK', '=', 'hoadonnhap.ID')
            ->select(DB::raw('count(tapphim.TapSo) as tongsotap'), DB::raw('sum(chitiethdn.GiaPhim) as TongchiPhi'))
            ->whereYear('hoadonnhap.NgayNhap', $year)
            ->whereMonth('hoadonnhap.NgayNhap', $month)
            ->get();

        return response()->json(['CountTap' => $totalEpisodes]);
    }
    public function thongkebymonth(Request $req)
    {
        $year = $req->input('year'); // Lấy năm từ request
        if ($year == null) {
            $year = 2023; //now()->year;
        }
        $startOfYear = $year . '-01-01';
        $endOfYear = $year . '-12-31';
        $total = DB::table('tapphim')
            ->join('chitiethdn', 'tapphim.ID', '=', 'chitiethdn.ID_TapPhim')
            ->join('hoadonnhap', 'chitiethdn.ID_PNK', '=', 'hoadonnhap.ID')
            ->select(DB::raw('count(tapphim.TapSo) as tongsotap'), DB::raw('sum(chitiethdn.GiaPhim) as TongchiPhi'))
            ->whereBetween('hoadonnhap.NgayNhap', [$startOfYear, $endOfYear])
            ->get();
        $totalEpisodes = DB::table('tapphim')
            ->join('chitiethdn', 'tapphim.ID', '=', 'chitiethdn.ID_TapPhim')
            ->join('hoadonnhap', 'chitiethdn.ID_PNK', '=', 'hoadonnhap.ID')
            ->select('hoadonnhap.NgayNhap', DB::raw('count(tapphim.TapSo) as tongsotap'), DB::raw('sum(chitiethdn.GiaPhim) as TongchiPhi'))
            ->whereBetween('hoadonnhap.NgayNhap', [$startOfYear, $endOfYear])
            ->groupBy('hoadonnhap.NgayNhap')
            ->get();
        return response()->json(['total' => $total, 'CountTap' => $totalEpisodes, 'year' => $year]);
    }





    public function thongke(Request $req)
    {
        $year = $req->year;
        $month = $req->month;
        $date = $req->date;
        if (!$year && !$month && !$date) {
            $lst = DB::table('tapphim')
                ->join('chitiethdn', 'tapphim.ID', '=', 'chitiethdn.ID_TapPhim')
                ->join('hoadonnhap', 'chitiethdn.ID_PNK', '=', 'hoadonnhap.ID')
                ->select(
                    DB::raw('YEAR(hoadonnhap.NgayNhap) AS thoigian'),
                    DB::raw('COUNT(tapphim.TapSo) AS tongsotap'),
                    DB::raw('SUM(chitiethdn.GiaPhim) AS TongchiPhi')
                )
                ->groupBy(DB::raw('YEAR(hoadonnhap.NgayNhap)'))
                ->get();
            return response()->json(['message' => 'test1', 'data' => $lst]);
        }
        if ($year && !$month && !$date) {
            $lst = DB::table('tapphim')
                ->join('chitiethdn', 'tapphim.ID', '=', 'chitiethdn.ID_TapPhim')
                ->join('hoadonnhap', 'chitiethdn.ID_PNK', '=', 'hoadonnhap.ID')
                ->select(
                    DB::raw('MONTH(hoadonnhap.NgayNhap) AS thoigian'),
                    DB::raw('COUNT(tapphim.TapSo) AS tongsotap'),
                    DB::raw('SUM(chitiethdn.GiaPhim) AS TongchiPhi')
                )
                ->whereYear('hoadonnhap.NgayNhap', $year)
                ->groupBy(DB::raw('MONTH(hoadonnhap.NgayNhap)'))
                ->get();
            return response()->json(['message' => 'test2', 'data' => $lst]);
        }
        if ($year && $month && !$date) {
            $lst = DB::table('tapphim')
                ->join('chitiethdn', 'tapphim.ID', '=', 'chitiethdn.ID_TapPhim')
                ->join('hoadonnhap', 'chitiethdn.ID_PNK', '=', 'hoadonnhap.ID')
                ->select(
                    DB::raw('hoadonnhap.NgayNhap AS thoigian'),
                    DB::raw('COUNT(tapphim.TapSo) AS tongsotap'),
                    DB::raw('SUM(chitiethdn.GiaPhim) AS TongchiPhi')
                )
                ->whereYear('hoadonnhap.NgayNhap', $year)
                ->whereMonth('hoadonnhap.NgayNhap', $month)
                ->groupBy(DB::raw('hoadonnhap.NgayNhap'))
                ->get();
            return response()->json(['message' => 'test3', 'data' => $lst]);
        }
        if ($year && $month && $date) {
            $lst = DB::table('tapphim')
                ->join('chitiethdn', 'tapphim.ID', '=', 'chitiethdn.ID_TapPhim')
                ->join('hoadonnhap', 'chitiethdn.ID_PNK', '=', 'hoadonnhap.ID')
                ->select(
                    'hoadonnhap.NgayNhap AS thoigian',
                    DB::raw('COUNT(tapphim.TapSo) AS tongsotap'),
                    DB::raw('SUM(chitiethdn.GiaPhim) AS TongchiPhi')
                )
                ->whereYear('hoadonnhap.NgayNhap', $year)
                ->whereMonth('hoadonnhap.NgayNhap', $month)
                ->whereDay('hoadonnhap.NgayNhap', $date)
                ->groupBy('hoadonnhap.NgayNhap')
                ->get();
            return response()->json(['message' => 'test4', 'data' => $lst]);
        }
    }
}

// //thông kê theo tháng của năm
// SELECT Month(hoadonnhap.NgayNhap) AS Thang, COUNT(tapphim.TapSo) AS tongsotap, SUM(chitiethdn.GiaPhim) AS TongchiPhi
// FROM tapphim
// JOIN chitiethdn ON tapphim.ID = chitiethdn.ID_TapPhim
// JOIN hoadonnhap ON chitiethdn.ID_PNK = hoadonnhap.ID
// WHERE Month(hoadonnhap.NgayNhap) BETWEEN 1 AND 12 AND Year(hoadonnhap.NgayNhap) = 2023
// GROUP BY Month(hoadonnhap.NgayNhap);

// //thông kê theo năm
// SELECT year(hoadonnhap.NgayNhap) AS Thang, COUNT(tapphim.TapSo) AS tongsotap, SUM(chitiethdn.GiaPhim) AS TongchiPhi
// FROM tapphim
// JOIN chitiethdn ON tapphim.ID = chitiethdn.ID_TapPhim
// JOIN hoadonnhap ON chitiethdn.ID_PNK = hoadonnhap.ID
// GROUP BY YEAR(hoadonnhap.NgayNhap);


//thống kê theo ngày tháng năm