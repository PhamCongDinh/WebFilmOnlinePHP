<?php

namespace App\Http\Controllers;

use App\Models\ChiTietHDN;
use App\Models\HangPhim;
use App\Models\HoaDon;
use App\Models\HoaDonNhap;
use App\Models\LoaiPhim;
use Illuminate\Support\Facades\DB;
use App\Models\Phim;
use App\Models\TapPhim;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class PhimandTapController extends Controller
{
    public function NewTapPhim(Request $req)
    {
        $hd = new HoaDonNhap();
        $hd->NgayNhap = now();
        $hd->save();
        $IdHd = $hd->ID;
        foreach ($req->all() as $phimData) {
            $ten_phim = $phimData['ten_phim'];
            $tapso = $phimData['tapso'];
            $Thoigianchieu = $phimData['thoigianchieu'];
            $thoihan = $phimData['thoihan'];
            $thoiluong = $phimData['thoiluong'];
            $url_trailer = $phimData['url_trailer'];
            $url_tapphim = $phimData['url_tapphim'];
            $giaphim = $phimData['giaphim'];
            $checktime = Phim::where('Ten_Phim', $ten_phim)->first();
            if (!$checktime) {
                return response()->json(['error' => 'Phim không tồn tại'], 400);
            }
            $ThoigianchieuDT = new DateTime($Thoigianchieu);
            $NgayPhatHanhDT = new DateTime($checktime->NgayPhatHanh);
            if ($ThoigianchieuDT < $NgayPhatHanhDT) {
                return response()->json(['error' => 'Thời gian chiếu phải lớn hơn hoặc bằng ngày phát hành'], 400);
            }
            $existingTapPhim  = DB::table('phim')
                ->join('tapphim', 'tapphim.ID_Phim', '=', 'phim.ID')
                ->select('phim.Ten_Phim', 'tapphim.TapSo')
                ->where('tapphim.TapSo', $tapso)
                ->where('phim.Ten_Phim', $ten_phim)
                ->get();
            if (!$existingTapPhim->isEmpty()) {
                return response()->json(['error' => 'Tập đã tồn tại', $existingTapPhim], 400);
            }
            $phim = Phim::firstOrCreate(['Ten_Phim' => $ten_phim]);
            $idPhim = $phim->ID;

            $tapphim = new TapPhim();
            $tapphim->TapSo = $tapso;
            $tapphim->ThoiGianChieu = $Thoigianchieu;
            $tapphim->ThoiHan = $thoihan;
            $tapphim->ThoiLuong = $thoiluong;
            $tapphim->URL_Phim = $url_tapphim;
            $tapphim->URL_Trailer = $url_trailer;
            $tapphim->ID_Phim = $idPhim;
            $tapphim->DanhGia = 0;
            $tapphim->save();

            $idTapPhim = $tapphim->ID;

            $chitiethdn = new ChiTietHDN();
            $chitiethdn->GiaPhim = $giaphim;
            $chitiethdn->ID_PNK = $IdHd;
            $chitiethdn->ID_TapPhim = $idTapPhim;
            $chitiethdn->save();
        }

        return response()->json(['success' => true], 200);
    }

    public function newphim(Request $req)
    {
        $phim = new Phim();
        $phim->Ten_Phim = $req->Ten_Phim;
        if ($req->hasFile('AnhPhim')) {
            $image = $req->file('AnhPhim');
            $imageName = $image->getClientOriginalName();
            $image->move('C:\Users\Dinh\Documents\HH3DView\view\images', $imageName);
            $phim->Anh_Phim = $imageName;
            // $check = Phim::where('Anh_Phim', $imageName)->first();
            // if ($check == null) {

            // }
        } else {
            $phim->Anh_Phim = 'default_image.jpg'; // Replace with your default image name
        }
        $phim->NgayPhatHanh = $req->NgayPhatHanh;
        $phim->ThoiLuongPhim = $req->ThoiLuongPhim;
        $phim->MoTa = $req->MoTa;
        $phim->ID_HangPhim = $req->TenHP;
        $phim->ID_LP = $req->Ten_LP;
        $phim->TongSoTap = $req->TongSoTap;
        $phim->save();
        return response()->json(['success', $phim], 200);
    }

    public function Danhsachtapphim($id)
    {
        $tapPhimData = DB::table('phim')
            ->join('tapphim', 'phim.ID', '=', 'tapphim.ID_Phim')
            ->select('tapphim.*', 'phim.Ten_Phim', 'phim.Anh_Phim')
            ->where('phim.ID', '=', $id)
            ->orderBy('TapSo', 'desc')
            ->get();
        return  $tapPhimData;
    }

    public function Getallphim()
    {
        $lst = DB::table('phim')
            ->join('loaiphim', 'phim.ID_LP', '=', 'loaiphim.ID')
            ->join('hangphim', 'phim.ID_HangPhim', '=', 'hangPhim.ID')
            ->select('phim.*', 'loaiphim.Ten_LP', 'hangphim.Ten_HangPhim')
            ->orderBy('phim.NgayPhatHanh', 'asc')
            ->get();
        return $lst;
    }
    public function gethl()
    {
        $lstLP = LoaiPhim::all();
        $lstHP = HangPhim::all();
        return response()->json([
            "LoaiPhim" => $lstLP,
            "HangPhim" => $lstHP
        ]);
    }

    public function deletephim($id)
    {
        ChiTietHDN::where('ID_TapPhim', $id)->delete();
        TapPhim::where('ID', $id)->delete();
        return response()->json('success', 200);
    }


    public function tapphimbyid($id)
    {
        $tapPhimData = DB::table('phim')
            ->join('tapphim', 'phim.ID', '=', 'tapphim.ID_Phim')
            ->select('tapphim.*', 'phim.Ten_Phim')
            ->where('tapphim.ID', '=', $id)
            ->get();
        return $tapPhimData;
    }
    public function editphim(Request $req)
    {
        $update = TapPhim::where('ID', $req->ID)
            ->update([
                'ThoiHan' => $req->ThoiHan,
                'TapSo' => $req->TapSo,
                'ThoiGianChieu' => $req->ThoiGianChieu,
                'ThoiLuong' => $req->ThoiLuong,
                'URL_Phim' => $req->URL_Phim,
                'URL_Trailer' => $req->URL_Trailer,
                'ID_Phim' => $req->ID_Phim
            ]);
        return response()->json(['success', $update], 200);
    }



    public function PhimByID($id)
    {
        $phimData = DB::table('phim')
            ->leftJoin('tapphim', 'tapphim.ID_Phim', '=', 'phim.ID')
            ->leftJoin('loaiphim', 'phim.ID_LP', '=', 'loaiphim.ID')
            ->leftjoin('HangPhim', 'phim.ID_HangPhim', '=', 'HangPhim.ID')
            ->select('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia', 'phim.ID_LP', 'loaiphim.Ten_LP', 'phim.ID_HangPhim', 'hangphim.Ten_HangPhim', DB::raw('COUNT(tapphim.TapSo) as SoLuongTap'))
            ->where('phim.ID', '=', $id)

            ->groupBy('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia', 'phim.ID_LP', 'loaiphim.Ten_LP', 'phim.ID_HangPhim', 'hangphim.Ten_HangPhim')
            ->get();

        return $phimData;
    }


    public function editbophim(Request $req)
    {

        if ($req->hasFile('AnhPhim')) {
            $image = $req->file('AnhPhim');
            $imageName = $image->getClientOriginalName();
            $image->move('C:\Users\Dinh\Documents\HH3DView\view\images', $imageName);
            $phim = $imageName;
        } else {

            $phim = $req->AnhPhim;
        }
        $updatebophim = Phim::where('ID', $req->ID)
            ->update([
                "Ten_Phim" => $req->Ten_Phim,
                "Anh_Phim" => $phim,
                "NgayPhatHanh" => $req->NgayPhatHanh,
                "ThoiLuongPhim" => $req->ThoiLuongPhim,
                "MoTa" => $req->MoTa,
                "ID_LP" => $req->ID_LP,
                "ID_HangPhim" => $req->ID_HangPhim,
                "TongSoTap" => $req->TongSoTap
            ]);
        return response()->json(['success' => $req->ID_LP], 200);
    }
}
