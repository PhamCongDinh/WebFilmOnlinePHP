<?php
// app/Http/Controllers/TapPhimController.php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

use App\Models\TapPhim;
use Illuminate\Http\Request;

class TapPhimController extends Controller
{
    public function GetTapPhim()
    {
        $tapPhimData = TapPhim::all();



        return  $tapPhimData;
    }
    public function GetTapPhimbyid($id)
    {
        $tapPhimData = DB::table('phim')
            ->join('tapphim', 'phim.ID', '=', 'tapphim.ID_Phim')
            ->select('tapphim.*', 'phim.Ten_Phim')
            ->where('phim.Ten_Phim', '=', $id)
            ->orderBy('TapSo', 'desc')
            ->get();

        return  $tapPhimData;
    }
    public function PlayPhim($id, $ten)
    {
        $tapPhimData = DB::table('phim')
            ->join('tapphim', 'phim.ID', '=', 'tapphim.ID_Phim')
            ->select('tapphim.*', 'phim.Ten_Phim')
            ->where([
                ['tapphim.TapSo', '=', $id],
                ['phim.Ten_Phim', '=', $ten],
            ])        //->orderBy('TapSo', 'desc')
            ->get();



        return  $tapPhimData;
    }
}
