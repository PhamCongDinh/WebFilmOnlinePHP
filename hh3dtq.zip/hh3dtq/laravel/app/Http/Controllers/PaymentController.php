<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TaiKhoan;
use Illuminate\Support\Facades\Validator;

class PaymentController extends Controller
{

    public function execPostRequest($url, $data)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt(
            $ch,
            CURLOPT_HTTPHEADER,
            array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($data)
            )
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        //execute post
        $result = curl_exec($ch);
        //close connection
        curl_close($ch);
        return $result;
    }
    public function on_checkout(Request $req)
    {
        $validate = Validator::make($req->all(), [
            'Ten_TK' => 'required|string|max:255|unique:taikhoan',
            'email' => 'required|string|email|max:255|unique:taikhoan',
            'MatKhau' => 'required|string|min:8',
        ]);
        if ($validate->fails()) {
            return response()->json(['errors' => $validate->errors()], 422);
        }
        $existingUser = TaiKhoan::where('Email', $req->email)->first();

        if ($existingUser) {
            // Nếu email đã tồn tại, trả về lỗi
            return response()->json(['error' => 'Email đã tồn tại'], 400);
        }
        $endpoint = "https://test-payment.momo.vn/v2/gateway/api/create";
        $partnerCode = 'MOMOBKUN20180529';
        $accessKey = 'klm05TvNBzhg7h7j';
        $secretKey = 'at67qH6mk8w5Y1nAyMoYKMWACiEi2bsa';

        $username = $req->Ten_TK;
        $email = $req->email;
        $password = $req->MatKhau;
        $orderInfo = "Thanh toán tài khoản";
        $amount = "10000";

        $orderId = time() . "";
        $redirectUrl = "http://127.0.0.1:5500/authen/thanks.html";
        $ipnUrl = "http://127.0.0.1:5500/authen/thanks.html";
        $extraData = "username=" . $username . "&password=" . $password . "&email=" . $email;

        $jsonExtraData = json_encode($extraData);
        $requestId = time() . "";
        $requestType = "payWithATM";

        $rawHash = "accessKey=" . $accessKey . "&amount=" . $amount . "&extraData=" . $jsonExtraData . "&ipnUrl=" . $ipnUrl . "&orderId=" . $orderId . "&orderInfo=" . $orderInfo . "&partnerCode=" . $partnerCode . "&redirectUrl=" . $redirectUrl . "&requestId=" . $requestId . "&requestType=" . $requestType; //. "&uername=" . $username . "&password=" . $password . "&email=" . $email;
        $signature = hash_hmac("sha256", $rawHash, $secretKey);
        $data = array(
            // 'username' => $username,
            // 'email' => $email,
            // 'password' => $password,
            'partnerCode' => $partnerCode,
            'partnerName' => "Test",
            "storeId" => "MomoTestStore",
            'requestId' => $requestId,
            'amount' => $amount,
            'orderId' => $orderId,
            'orderInfo' => $orderInfo,
            'redirectUrl' => $redirectUrl,
            'ipnUrl' => $ipnUrl,
            'lang' => 'vi',
            'extraData' => $jsonExtraData,
            'requestType' => $requestType,
            'signature' => $signature
        );
        $result = $this->execPostRequest($endpoint, json_encode($data));
        $jsonResult = json_decode($result, true);
        if (isset($jsonResult['payUrl'])) {

            return $jsonResult['payUrl'];
        } else {
            return response()->json(['error' => 'Unable to access payment URL'], 500);
        }
        // test momo:
        // NGUYEN VAN A
        // 9704 0000 0000 0018
        // 03/07
        // OTP
    }
}
