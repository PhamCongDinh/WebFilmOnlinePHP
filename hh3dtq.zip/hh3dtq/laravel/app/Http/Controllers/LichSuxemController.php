<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\LichSuPhim;
use Illuminate\Http\Request;

class LichSuxemController extends Controller
{
    public function addlsxem(Request $req)
    {
        $lsx = LichSuPhim::create([
            'ID_TapPhim' => $req->ID_TapPhim,
            'ID_TK' => $req->ID_TK,
            'create_at' => now(),
        ]);
        return response()->json(['success' => $lsx], 200);
    }

    public function getalllsxem(Request $req)
    {
        $lst = DB::table('lichsuphim')
            ->join('tapphim', 'tapphim.ID', '=', 'lichsuphim.ID_TapPhim')
            ->join('phim', 'phim.ID', '=', 'tapphim.ID_Phim')
            ->join('taikhoan', 'lichsuphim.ID_TK', '=', 'taikhoan.ID')
            ->select('phim.Ten_Phim', 'phim.Anh_Phim', 'tapphim.TapSo', 'lichsuphim.create_at')
            ->where('taikhoan.ID', '=', $req->ID)->orderByDesc('lichsuphim.create_at')
            ->get();
        return $lst;
    }
}
