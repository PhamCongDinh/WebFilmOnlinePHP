<?php
// app/Http/Controllers/PhimController.php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\Phim;
use Illuminate\Http\Request;

class GetPhimByIDController extends Controller
{
    public function GetPhimByID($id)
    {
        $phimData = DB::table('phim')
            ->leftJoin('tapphim', 'tapphim.ID_Phim', '=', 'phim.ID')
            ->leftJoin('loaiphim', 'phim.ID_LP', '=', 'loaiphim.ID')
            ->leftJoin('tacgia', 'phim.ID_TacGia', '=', 'tacgia.ID')
            ->select('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia', 'loaiphim.Ten_LP', 'tacgia.TenGia', DB::raw('COUNT(tapphim.TapSo) as SoLuongTap'))
            ->where('phim.Ten_Phim', '=', $id)

            ->groupBy('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia', 'loaiphim.Ten_LP', 'tacgia.TenGia')
            ->get();

        return $phimData;
    }
}
