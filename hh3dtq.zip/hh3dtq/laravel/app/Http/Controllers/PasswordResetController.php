<?php

namespace App\Http\Controllers;

use App\Models\TaiKhoan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class PasswordResetController extends Controller
{
    public function sendResetLink(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $taikhoan = TaiKhoan::where('Email', $request->email)->first();
        if ($taikhoan == null) {
            return response()->json(['message' => 'Email does not exist'], 404);
        }

        $newPassword = Str::random(8);
        $taikhoan->MatKhau = bcrypt($newPassword);
        $taikhoan->save();

        try {
            Mail::send('emails.reset_password', ['user' => $taikhoan, 'newPassword' => $newPassword], function ($message) use ($taikhoan) {
                $message->to($taikhoan->Email);
                $message->subject('Your New Password');
            });
        } catch (\Exception $e) {
            return response()->json(['message' => 'Failed to send email: ' . $e->getMessage()], 500);
        }

        return response()->json(['message' => 'A new password has been sent to your email address.']);
    }

    public function changepassword(Request $req)
    {
        $taikhoan = TaiKhoan::where('ID', $req->ID)->first();

        if (!$taikhoan) {
            return response()->json(['message' => 'Người dùng không tồn tại'], 404);
        }

        if (Hash::check($req->matkhau, $taikhoan->MatKhau)) {
            $taikhoan->MatKhau = bcrypt($req->matkhaumoi);
            $taikhoan->save();

            return response()->json(['message' => 'Đổi mật khẩu thành công', 'data' => $taikhoan]);
        } else {
            return response()->json(['message' => 'Mật khẩu không đúng'], 400);
        }
    }
}
