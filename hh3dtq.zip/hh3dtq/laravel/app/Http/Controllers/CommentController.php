<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\BinhLuan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CommentController extends Controller
{
    public function comment(Request $req)
    {
        if ($req == null) {
            return response()->json(['error'], 500);
        } else {
            $validator = Validator::make($req->all(), [
                'NoiDung' => [
                    'required',
                    'string',
                    'not_regex:/\b(vl|vcl|dcm)\b/i',
                ],
            ]);

            if ($validator->fails()) {
                return response()->json(['errors' => "xin bạn hãy kiềm chế và không vi phạm chuẩn mực ngôn từ"], 422);
            } else {
                $cmmt = BinhLuan::create([
                    'NoiDung' => $req->NoiDung,
                    'ThoiGian' => now(),
                    'ID_TapPhim' => $req->ID_TapPhim,
                    'ID_TK' => $req->ID_TK
                ]);
                return response()->json(['success' => $cmmt], 200);
            }
        }
    }
    public function deletecmmt(Request $req)
    {
        $del = BinhLuan::where('ID_TapPhim', $req->ID_TapPhim)
            ->where('ID_TK', $req->ID_TK)
            ->delete();
        return response()->json(['success'], 200);
    }
    public function getallcmmt(Request $req)
    {
        $lst = DB::table('taikhoan')
            ->join('binhluan', 'taikhoan.ID', '=', 'binhluan.ID_TK')
            ->join('tapphim', 'binhluan.ID_tapphim', '=', 'tapphim.ID')
            ->join('phim', 'tapphim.ID_phim', '=', 'phim.ID')
            ->select('taikhoan.Email', 'taikhoan.Ten_TK', 'binhluan.NoiDung')
            ->where([
                ['tapphim.TapSo', '=', $req->TapSo],
                ['phim.Ten_Phim', '=', $req->Ten_Phim],
            ])
            ->get();
        return response()->json(['success' => $lst], 200);
    }
}
