<?php
// app/Http/Controllers/PhimController.php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\LoaiPhim;
use App\Models\Phim;
use Illuminate\Http\Request;

class PhimByTheLoaiController extends Controller
{
    public function GetTheLoai()
    {
        $loaiphimData = LoaiPhim::all();
        return $loaiphimData;
    }
    public function GetPhimByTheLoai($id)
    {
        $phimData = DB::table('phim')
            ->leftJoin('tapphim', 'tapphim.ID_Phim', '=', 'phim.ID')
            ->leftJoin('loaiphim', 'phim.ID_LP', '=', 'loaiphim.ID') // Thêm join với bảng loaiphim
            ->select('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'DanhGia', 'loaiphim.Ten_LP', DB::raw('COUNT(tapphim.TapSo) as SoLuongTap'))
            // ->where('phim.id', '=', $id)
            ->where('loaiphim.Ten_LP', '=', $id)

            ->groupBy('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'DanhGia', 'loaiphim.Ten_LP')
            ->get();

        return $phimData;
    }
}
