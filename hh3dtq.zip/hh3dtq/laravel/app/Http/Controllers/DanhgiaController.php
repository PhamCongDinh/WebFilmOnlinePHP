<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\DanhGia;
use Illuminate\Http\Request;

class DanhgiaController extends Controller
{
    public function danhgia(Request $req)
    {
        $check = DanhGia::where('ID_TK', $req->ID_TK)->where('ID_TapPhim', $req->ID_TapPhim)->first();

        if ($check) {

            //$check->SoDiem = $req->SoDiem;
            //$check->ThoiGian = now();
            $update = DanhGia::where('ID', $check->ID)
                ->update([
                    'SoDiem' => $req->SoDiem,
                    'ThoiGian' => now(),
                    'ID_TapPhim' => $req->ID_TapPhim,
                    'ID_TK' => $req->ID_TK
                ]);
            return response()->json(['success' => true, $check], 200);
        } else {
            $dg = DanhGia::create([
                'SoDiem' => $req->SoDiem,
                'ThoiGian' => now(),
                'ID_TapPhim' => $req->ID_TapPhim,
                'ID_TK' => $req->ID_TK
            ]);
            return response()->json(['success' => true, $dg], 200);
        }
    }

    public function getsodiem(Request $req)
    {
        $sodiem = DanhGia::Where('ID_TapPhim', '=', $req->ID_TapPhim)
            ->Where('ID_TK', '=', $req->ID_TK)
            ->get();
        return response()->json(['success' => true, 'data' => $sodiem], 200);
    }
}
