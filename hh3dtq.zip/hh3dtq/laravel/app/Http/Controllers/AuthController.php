<?php

namespace App\Http\Controllers;

use App\Models\HoaDon;
use Illuminate\Http\Request;
use App\Models\TaiKhoan;
use DateTime;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Firebase\JWT\JWT;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{




    public function login(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'email' => 'required|email|max:255',
            'matkhau' => 'required|string|min:6',
        ]);
        if ($validate->fails()) {
            return response()->json(['errors' => $validate->errors()], 422);
        }
        $email = $request->input('email');
        $password = $request->input('matkhau');
        $user = TaiKhoan::where('Email', $email)->first();
        if ($user && Hash::check($password, $user->MatKhau)) {
            $payload = [
                'iss' => 'dinh.com',
                'aud' => 'sinhvien',
                'iat' => time(),
                'exp' => time() + (3600 * 24),
                'sub' => $user->ID,
                'jti' => uniqid()
            ];

            $key = 'ThisIsAVeryLongAndSecureSecretKeyForJWTTokenGeneration';

            $algorithm = 'HS256';

            $token = JWT::encode($payload, $key, $algorithm);
            return response()->json(['token' => $token, 'userID' => $user->ID], 200);
        } else {
            return response()->json(['error' => 'Email hoặc mật khẩu không đúng'], 404);
        }
    }

    public function registers(Request $request)
    {
        $user = TaiKhoan::create([
            'Ten_TK' => $request->TenTK,
            'MatKhau' => bcrypt($request->matkhau),
            'Email' => $request->email,
            'Loai_TK' => $request->loai
        ]);
        $userId = $user->ID;
        $hd = HoaDon::create([
            'ID' => $request->IDhd,
            'SoTien' => $request->gia,
            'create_at' => now(),
            'ID_TK' => $userId
        ]);
        $hd->save();
        return response()->json([
            'code' => 200,
            'data' => $user
        ], 200);
    }
}
