<?php
// app/Http/Controllers/PhimController.php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\Phim;
use Illuminate\Http\Request;

class PhimController extends Controller
{


    // function getPaginatedPhimData(Request $request)
    // {
    //     $perPage = 3; // Số lượng phim mỗi trang
    //     $page = $request->query('page', 1); // Lấy trang hiện tại từ query string, mặc định là trang 1
    //     $offset = ($page - 1) * $perPage; // Tính offset

    //     $phimData = DB::table('phim')
    //         ->leftJoin('tapphim', 'tapphim.ID_Phim', '=', 'phim.ID')
    //         ->select('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'DanhGia', DB::raw('COUNT(tapphim.TapSo) as SoLuongTap'))
    //         ->groupBy('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'DanhGia')
    //         ->offset($offset) // Bỏ qua số lượng phim đã qua
    //         ->limit($perPage) // Giới hạn số lượng phim trên mỗi trang
    //         ->get();

    //     return $phimData;
    // }
    function getPaginatedPhimData(Request $request)
    {
        $perPage = 8;
        $page = $request->query('page', 1);
        $totalPhim = DB::table('phim')->count();
        $totalPages = ceil($totalPhim / $perPage);
        $offset = ($page - 1) * $perPage;
        $phimData = DB::table('phim')
            ->leftJoin('tapphim', 'tapphim.ID_Phim', '=', 'phim.ID')
            ->select('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia', DB::raw('COUNT(tapphim.TapSo) as SoLuongTap'))
            ->groupBy('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia')
            ->offset($offset)
            ->limit($perPage)
            ->get();
        return [
            'phimData' => $phimData,
            'totalPages' => $totalPages
        ];
    }
    public function GetPhim()
    {
        $phimData = DB::table('phim')
            ->leftJoin('tapphim', 'tapphim.ID_Phim', '=', 'phim.ID')
            ->select('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia', DB::raw('COUNT(tapphim.TapSo) as SoLuongTap'))
            ->groupBy('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia')
            ->get();
        return $phimData;
    }
    public function SearchPhim($key)
    {
        $phimData = DB::table('phim')
            ->leftJoin('tapphim', 'tapphim.ID_Phim', '=', 'phim.ID')
            ->select('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia', DB::raw('COUNT(tapphim.TapSo) as SoLuongTap'))
            ->where('phim.Ten_Phim', 'LIKE', '%' . $key . '%')
            ->groupBy('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia')
            ->get();
        return $phimData;
    }

    public function danhSachPhimTheoThu($thu)
    {
        $danhSachPhim = DB::table('phim')
            ->leftJoin('tapphim', 'tapphim.ID_Phim', '=', 'phim.ID')
            ->select('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'phim.DanhGia', 'phim.MoTa', DB::raw('COUNT(tapphim.ID) as SoLuongTap'))
            ->joinSub(function ($query) use ($thu) {
                $query->from('tapphim')
                    ->select('ID_Phim')
                    ->whereRaw('DAYOFWEEK(ThoiGianChieu) = ?', [$thu])
                    ->distinct();
            }, 'tapphim_filtered', function ($join) {
                $join->on('phim.ID', '=', 'tapphim_filtered.ID_Phim');
            })
            ->groupBy('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'phim.DanhGia', 'phim.MoTa')
            ->get();

        return $danhSachPhim;
    }
    public function phimxemnhieunhat()
    {
        $movies = DB::table('lichsuphim AS lhv')
            ->join('tapphim AS t', 'lhv.ID_TapPhim', '=', 't.ID')
            ->join('phim AS p', 't.ID_Phim', '=', 'p.ID')
            ->select('p.Ten_Phim', 'p.Anh_Phim', DB::raw('COUNT(lhv.ID_TapPhim) AS SoLanXem'))
            ->groupBy('p.Ten_Phim', 'p.Anh_Phim')
            ->orderBy('SoLanXem', 'desc')
            ->limit(5)
            ->get();

        return $movies;
    }
    public function latestMovies()
    {
        $latestMovies = Phim::join('tapphim', 'phim.ID', '=', 'tapphim.ID_Phim')
            ->select(
                'phim.ID',
                'phim.Ten_Phim',
                'phim.TongSoTap',
                'phim.Anh_Phim',
                'NgayPhatHanh',
                'ThoiLuongPhim',
                'MoTa',
                'phim.DanhGia',
                DB::raw('COUNT(tapphim.TapSo) as SoLuongTap'),
                DB::raw('MAX(tapphim.ThoiGianChieu) as latest_airing_time')
            )
            ->groupBy('phim.ID', 'phim.Ten_Phim', 'phim.TongSoTap', 'phim.Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'phim.DanhGia')
            ->orderBy('latest_airing_time', 'desc')
            ->limit(8)
            ->get();

        return $latestMovies;
    }
}
