<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BinhLuan extends Model
{
    use HasFactory;
    protected $table = 'binhluan';
    protected $fillable = [
        'NoiDung', 'ThoiGian', 'ID_TapPhim', 'ID_TK'
    ];
    public $timestamps = false; // Nếu không sử dụng timestamp

}
