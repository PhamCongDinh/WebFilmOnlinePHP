<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HoaDon extends Model
{
    protected $table = 'hoadon';
    protected $primaryKey = 'ID';
    protected $fillable = [
        'ID', 'SoTien', 'create_at', 'ID_TK'
    ];
    public $timestamps = false; // Nếu không sử dụng timestamp

}
