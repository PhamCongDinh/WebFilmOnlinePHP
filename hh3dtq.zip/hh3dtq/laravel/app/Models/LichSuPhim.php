<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LichSuPhim extends Model
{
    use HasFactory;
    protected $table = 'lichsuphim';
    protected $fillable = [
        'ID', 'ID_TapPhim', 'ID_TK', 'create_at'
    ];
    public $timestamps = false;
}
