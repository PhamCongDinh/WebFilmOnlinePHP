<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChiTietHDN extends Model
{
    protected $table = 'chitiethdn';
    protected $primaryKey = 'ID';

    protected $fillable = [
        'ID', 'GiaPhim', 'ID_PNK', 'ID_TapPhim'
    ];
    public $timestamps = false; // Nếu không sử dụng timestamp

}
