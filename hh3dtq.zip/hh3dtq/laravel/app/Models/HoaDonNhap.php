<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HoaDonNhap extends Model
{
    protected $table = 'hoadonnhap';
    protected $primaryKey = 'ID';
    protected $fillable = [
        'ID', 'NgayNhap'
    ];
    public $timestamps = false; // Nếu không sử dụng timestamp

}
