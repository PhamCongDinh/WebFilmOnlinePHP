<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class Phim extends Model
{
    protected $table = 'phim';
    protected $primaryKey = 'ID';
    public $timestamps = false; // Nếu không sử dụng timestamp

    // Các cột trong bảng phim
    protected $fillable = [
        'ID', 'Ten_Phim', 'Anh_Phim', 'NgayPhatHanh', 'ThoiLuongPhim', 'MoTa', 'DanhGia', 'ID_HangPhim', 'ID_LP', 'TongSoTap'
    ];
}
?>