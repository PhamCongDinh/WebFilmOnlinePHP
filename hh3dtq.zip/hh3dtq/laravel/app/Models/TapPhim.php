<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class TapPhim extends Model
{
    protected $table = 'tapphim';
    protected $primaryKey = 'ID';
    public $timestamps = false;

    protected $fillable = [
        'ID', 'ThoiHan', 'TapSo', 'ThoiGianChieu', 'ThoiLuong', 'URL_Phim', 'URL_Trailer', 'ID_Phim'
    ];
}
?>