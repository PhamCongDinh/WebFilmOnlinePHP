<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HangPhim extends Model
{
    use HasFactory;

    protected $table = 'hangphim'; // Tên bảng trong CSDL
    protected $primaryKey = 'ID';

    protected $fillable = [
        'Ten_HangPhim', // Các cột có thể được gán giá trị thông qua mass assignment
    ];

    // Các phương thức và tương tác khác có thể được thêm vào đây
}
