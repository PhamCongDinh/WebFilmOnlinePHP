<?php

namespace App\Models;

use Laravel\Sanctum\HasApiTokens;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TaiKhoan extends Model
{
    use HasFactory, HasApiTokens;
    protected $table = 'taikhoan';
    protected $primaryKey = 'ID';
    protected $fillable = ['Ten_TK', 'MatKhau', 'Email', 'Loai_TK'];
    public $timestamps = false; // Nếu không sử dụng timestamp

}
