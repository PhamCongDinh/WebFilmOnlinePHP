<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\PhimController;
use App\Http\Controllers\GetPhimByIDController;

use App\Http\Controllers\TapPhimController;
use App\Http\Controllers\PhimByTheLOaiController;
use App\Http\Middleware\AuthenticateMiddleware;

Route::get('/phim', [PhimController::class, 'GetPhim']);
Route::get('/search-phim/{key}', [PhimController::class, 'SearchPhim']);
// routes/web.php
Route::get('/phimmoinhat', [PhimController::class, 'latestMovies']);
Route::get('/danh-sach-phim/{thu}', [PhimController::class, 'danhSachPhimTheoThu']);
Route::get('/phimbyid/{id}', [GetPhimByIDController::class, 'GetPhimById']);
Route::get('phimhaynhat', [PhimController::class, 'phimxemnhieunhat']);
Route::get('/tapphim', [TapPhimController::class, 'GetTapPhim']);
Route::get('/tapphimbyid/{id}', [TapPhimController::class, 'GetTapPhimbyid']);
// Route::get('/playphim/{id}/{ten}', [TapPhimController::class, 'PlayPhim']);

Route::middleware([AuthenticateMiddleware::class])->get('/playphim/{id}/{ten}', [TapPhimController::class, 'PlayPhim']);


Route::get('/theloai', [PhimByTheLOaiController::class, 'GetTheLoai']);
Route::get('/phimbytheloai/{id}', [PhimByTheLOaiController::class, 'GetPhimByTheLoai']);
