<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BaoCaoThongKe;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\DanhgiaController;
use App\Http\Controllers\LichSuxemController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\PhimandTapController;
use App\Http\Controllers\PhimController;
use App\Http\Middleware\AuthenticateMiddleware;

Route::post('/login', [AuthController::class, 'login']);

Route::post('/registers', [AuthController::class, 'registers']);
Route::post('/comment', [CommentController::class, 'comment']);
Route::delete('/delete', [CommentController::class, 'deletecmmt']);
Route::get('/getallcmmt', [CommentController::class, 'getallcmmt']);
Route::post('/danhgia', [DanhgiaController::class, 'danhgia']);


Route::get('page', [PhimController::class, 'getPaginatedPhimData']);


Route::post('addlsxp', [LichSuxemController::class, 'addlsxem']);
Route::get('getalllsx', [LichSuxemController::class, 'getalllsxem']);


Route::post('newtapphim', [PhimandTapController::class, 'NewTapPhim']);
Route::post('newphim', [PhimandTapController::class, 'newphim']);
Route::get('danhsachphim/{id}', [PhimandTapController::class, 'Danhsachtapphim']);

Route::get('getphim', [PhimandTapController::class, 'Getallphim']);
// Route::middleware([AuthenticateMiddleware::class])->get('getphim', [PhimandTapController::class, 'Getallphim']);
Route::get('getlh', [PhimandTapController::class, 'gethl']);
Route::delete('deletephim/{id}', [PhimandTapController::class, 'deletephim']);


Route::get('detail/{id}', [PhimandTapController::class, 'tapphimbyid']);
Route::put('updatephim', [PhimandTapController::class, 'editphim']);
Route::post('thanhtoan', [PaymentController::class, 'on_checkout']);


Route::post('editbophim', [PhimandTapController::class, 'editbophim']);

//thongke
//Route::get('thongke', [BaoCaoThongKe::class, 'ThongkeTK']);
Route::get('ThongKeTapPhim', [BaoCaoThongKe::class, 'ThongKeTapPhim']);
Route::get('thongkebymonth', [BaoCaoThongKe::class, 'thongkebymonth']);
Route::get('thongke', [BaoCaoThongKe::class, 'thongke']);

Route::post('forgot-password', [PasswordResetController::class, 'sendResetLink']);
Route::post('changepassword', [PasswordResetController::class, 'changepassword']);
